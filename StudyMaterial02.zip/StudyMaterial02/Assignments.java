___________________________________________________________

DAY 1 
___________________________________________________________

A1. READING ASSINGMENTS [ MUST ]
	Single Precision Floating Point [ Wikipedia Arctile ]
	Double Precision Floating Point [ Wikipedia Arctile ]

A2. READING ASSINGMENTS [ MUST MUST ]
	Chapter 05: Pointers and Array
	Reference: The C Programming Language
				Kernigham and Dennis Rithie

___________________________________________________________

DAY 02
___________________________________________________________

A1. READING ASSINGMENTS [ MUST ]
	Single Precision Floating Point [ Wikipedia Arctile ]
	Double Precision Floating Point [ Wikipedia Arctile ]

A2. READING ASSINGMENTS [ MUST MUST ]
	Chapter 05: Pointers and Array
	Reference: The C Programming Language
				Kernigham and Dennis Rithie

A3. CODING ASSINGMENTS [ MUST MUST ]
	Simulate 2D and 3D Dynamic Arrays in C


A4. CODING PRACTICE AND REVISION ASSINGMENTS [ MUST MUST ]
	Practice and Revise Java Code Done Till Now
___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________

