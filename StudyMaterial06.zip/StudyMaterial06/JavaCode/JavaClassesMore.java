/*
javac JavaClassesMore.java -d build
java -cp build/ learnJava.JavaClassesMore
*/

package learnJava;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;
import java.time.LocalDate;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Scanner;


// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Objects;

import static java.lang.Math.*;

// _________________________________________________________________

enum Size {
	SMALL("S"), MEDIUM("M"), LARGE("L"), EXTRA_LARGE("XL");

	private String abbreviation;

	Size(String abbreviation) {
		this.abbreviation = abbreviation;
	}

	public String getAbbreviation() { return abbreviation; }
}


class EnumDemo {
	public static void playWithEnums() {
		Size notMySize = Size.valueOf("SMALL");
		System.out.println(notMySize);
		
		for (Size s : Size.values()) { System.out.println(s); }
		
		System.out.println(Size.MEDIUM.ordinal());
	}
}


// _________________________________________________________________

enum Operation {
	ADD("+") {
		public int evaluate(int arg1, int arg2) { return arg1 + arg2; }
	},
	SUBTRACT("-") {
		public int evaluate(int arg1, int arg2) { return arg1 - arg2; }
	},
	MULTIPLY("*") {
		public int evaluate(int arg1, int arg2) { return arg1 * arg2; }
	},
	DIVIDE("/") {
		public int evaluate(int arg1, int arg2) { return arg1 / arg2; }
	};

	private String symbol;
	Operation(String symbol) { this.symbol = symbol; }
	public String getSymbol() { return symbol; }    
	public abstract int evaluate(int arg1, int arg2);
}

class Calculator {

	// public static int evaluate(Operation op, int arg1, int arg2) {
	//     int result = 0;
	//     switch (op) {
	//         case ADD: result = arg1 + arg2; break;
	//         case SUBTRACT: result = arg1 - arg2; break;
	//         case MULTIPLY: result = arg1 * arg2; break;
	//         case DIVIDE: result = arg1 / arg2; break;
	//     }
	//     return result;
	// }

	public static void calculate() {
		Scanner in = new Scanner(System.in);
		System.out.print("First operand: ");
		int a = in.nextInt();
		System.out.print("Operator: ");
		String opSymbol = in.next();
		System.out.print("Second operand: ");
		int b = in.nextInt();
		for (Operation op : Operation.values()) {
			if (op.getSymbol().equals(opSymbol)) {
				int result = op.evaluate(a, b);
				System.out.println(result);
			} 
		}
	}
}

// _________________________________________________________________
// _________________________________________________________________

interface IntSequence {
	boolean hasNext();
	int next();
}

class LocalClassDemo {
	private static Random generator = new Random();

	public static IntSequence randomInts(int low, int high) {
		// Local Class : Class Defined Inside Function
		//		Local Classes Are Used Inside Function Only
		class RandomSequence implements IntSequence {
			public int next() { return low + generator.nextInt(high - low + 1); }
			public boolean hasNext() { return true; }
		}

		return new RandomSequence();
	}

	public static void playWithLocalClass() {
		IntSequence dieTosses = randomInts(1, 6);
		for (int i = 0; i < 10; i++) System.out.println(dieTosses.next());
	}
}

// _________________________________________________________________
// _________________________________________________________________


class CreditCardForm {
	private static final ArrayList<Integer> expirationYear = new ArrayList<>();

	// Static Block
	//		To Initialise Static Member Variables
	static {
		// Add the next twenty years to the array list
		int year = LocalDate.now().getYear();
		for (int i = year; i <= year + 20; i++) {
			expirationYear.add(i);
		}   
	}
	// ...
}

// _________________________________________________________________


class StaticImportDemo {
	public static void playWithStaticImport() {
		double x = 3;
		double y = 4;
		// i.e., Math.sqrt, Math.pow
		double hypothenuse = sqrt(pow(x, 2) + pow(y, 2)); 
		System.out.println(hypothenuse);        
	}
}

// _________________________________________________________________
// _________________________________________________________________


class Card {
	// Inner Class
	//		Suit Is Inner Class Of Card Class
	class Suit {

	}

}


// _________________________________________________________________
// _________________________________________________________________


class OuterClass { // Outer Context
	int x = 10;

	// INNER CLASS
	public class InnerClass { // Inner Context
		int y = 5;

		// Inner Class/Context Can Access Outer Class/Context
		int mixOuterInInnerState() {
			return x + y;
		}
	}
}

class InnerClassDemo {
	public static void playWithInnerClass() {
		OuterClass myOuter = new OuterClass();
		OuterClass.InnerClass myInner = myOuter.new InnerClass();
		System.out.println(myInner.y + myOuter.x);

		System.out.println(myInner.mixOuterInInnerState() );  
  }
}

// _________________________________________________________________
// _________________________________________________________________


class OuterClassAgain { // Outer Context
	int x = 10;

	// NESTED CLASS
	//		Static Class Defined Inside Class
	static public class NestedClass { // Nested Context
		int y = 5;

		// Nested Class/Context Can Access Outer Class/Context
		int mixOuterInInnerState() {
			// Compilation Error
			// 		error: non-static variable x cannot be referenced 
			// 		from a static context
			// return x + y;
			return y;
		}
	}
}

class NestedClassDemo {
	public static void playWithNestedClass() {
		OuterClassAgain myOuter = new OuterClassAgain();
		OuterClassAgain.NestedClass myNested = new OuterClassAgain.NestedClass();
		System.out.println(myNested.y + myOuter.x);

		System.out.println(myNested.mixOuterInInnerState() );  
  }
}

// _________________________________________________________________
// _________________________________________________________________

class Network {
	// Inner Class
	//		Class Defined Inside Class

	public class Member { // Member is an inner class of Network
		private String name;
		private ArrayList<Member> friends = new ArrayList<>();

		public Member(String name) {
			this.name = name;
		}

		public void deactivate() {
			members.remove(this);
		}

		public void addFriend(Member newFriend) {
			friends.add(newFriend);
		}

		public boolean belongsTo(Network n) {
			return Network.this == n;
		}
		
		public String toString() {
			StringBuilder result = new StringBuilder(name);
			result.append(" with friends ");
			for (Member friend : friends) {
				result.append(friend.name);
				result.append(", ");
			}
			return result.subSequence(0, result.length() - 2).toString();
		}
	}

	private ArrayList<Member> members = new ArrayList<>();

	public Member enroll(String name) {
		Member newMember = new Member(name);
		members.add(newMember);
		return newMember;
	}

	public String toString() {
		return members.toString();
	}
}

class NetworkDemo {
	public static void playWithInnerClass() {
		Network myFace = new Network();
		Network tooter = new Network();
		Network.Member fred = myFace.enroll("Fred");
		Network.Member wilma = myFace.new Member("Wilma");
		fred.addFriend(wilma);

		Network.Member barney = tooter.enroll("Barney");
		fred.addFriend(barney);
		System.out.println(myFace);
		System.out.println(barney.belongsTo(myFace));
	}
}


// _________________________________________________________________
// _________________________________________________________________


class ProfessionalDataStructure {    
	// Create an array
	private final static int SIZE = 15;
	private int[] arrayOfInts = new int[SIZE];
	
	public ProfessionalDataStructure() {
		// fill the array with ascending integer values
		for (int i = 0; i < SIZE; i++) {
			arrayOfInts[i] = i;
		}
	}
	
	public void printEven() {
		// Print out values of even indices of the array
		DataStructureIterator iterator = this.new EvenIterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + " ");
		}
		System.out.println();
	}
	
	interface DataStructureIterator extends java.util.Iterator<Integer> { } 

	// Inner class implements the DataStructureIterator interface,
	// which extends the Iterator<Integer> interface
	private class EvenIterator implements DataStructureIterator {
		// Start stepping through the array from the beginning
		private int nextIndex = 0;
		
		public boolean hasNext() {
			// Check if the current element is the last in the array
			return (nextIndex <= SIZE - 1);
		}        
		
		public Integer next() {
			// Record a value of an even index of the array
			Integer retValue = Integer.valueOf(arrayOfInts[nextIndex]);
			
			// Get the next even element
			nextIndex += 2;
			return retValue;
		}
	}
}


class ProfessionalDataStructureDemo {	
	public static void playWithDataStructure() {		
		// Fill the array with integer values and print out only
		// values of even indices
		ProfessionalDataStructure ds = new ProfessionalDataStructure();
		ds.printEven();
	}
}

// _________________________________________________________________
// _________________________________________________________________


class LocalClassExample {  
	static String regularExpression = "[^0-9]";
  
	public static void validatePhoneNumber(
		String phoneNumber1, String phoneNumber2) {  
		final int numberLength = 10;
		// Valid in JDK 8 and later:
		// int numberLength = 10;
	   
		class PhoneNumber {
			String formattedPhoneNumber = null;

			PhoneNumber(String phoneNumber){
				// numberLength = 7;
				String currentNumber = phoneNumber.replaceAll(
				  regularExpression, "");
				if (currentNumber.length() == numberLength)
					formattedPhoneNumber = currentNumber;
				else
					formattedPhoneNumber = null;
			}

			public String getNumber() {
				return formattedPhoneNumber;
			}
			
			// Valid in JDK 8 and later:
//            public void printOriginalNumbers() {
//                System.out.println("Original numbers are " + phoneNumber1 +
//                    " and " + phoneNumber2);
//            }
		}

		PhoneNumber myNumber1 = new PhoneNumber(phoneNumber1);
		PhoneNumber myNumber2 = new PhoneNumber(phoneNumber2);
		
		// Valid in JDK 8 and later:
//        myNumber1.printOriginalNumbers();

		if (myNumber1.getNumber() == null) 
			System.out.println("First number is invalid");
		else
			System.out.println("First number is " + myNumber1.getNumber());
		if (myNumber2.getNumber() == null)
			System.out.println("Second number is invalid");
		else
			System.out.println("Second number is " + myNumber2.getNumber());

	}

}

class LocalClassExampleDemo {
	public static void playWithLocalClass() {
		LocalClassExample localClass = new LocalClassExample();
		localClass.validatePhoneNumber("123-456-7890", "456-7890");
	}
}

// _________________________________________________________________
// _________________________________________________________________

class EnglishVinglish {

	// Local Classes Are Like Inner Classes

	// Local classes are non-static because they have access 
	// to instance members of the enclosing block. 
	// Consequently, they cannot contain most kinds of 
	// static declarations.

/*
	public void greetInEnglish() {        
		// You cannot declare an interface inside a block; 
		// interfaces are inherently static.
		interface HelloThere {
		   public void greet();
		}

		class EnglishHelloThere implements HelloThere {
			public void greet() {
				System.out.println("Hello " + name);
			}
		}

		HelloThere myGreeting = new EnglishHelloThere();
		myGreeting.greet();
	}

	public void sayGoodbyeInEnglish() {
		class EnglishGoodbye {
			// You cannot declare static initializers or 
			// member interfaces in a local class.
			public static void sayGoodbye() {
				System.out.println("Bye bye");
			}
		}
		EnglishGoodbye.sayGoodbye();
	}

	*/

	// A local class can have static members provided that they are 
	// constant variables. (A constant variable is a variable of 
	// primitive type or type String that is declared final and 
	// initialized with a compile-time constant expression. A compiletime 
	// constant expression is typically a string or an arithmetic 
	// expression that can be evaluated at compile time

	public void sayGoodbyeInEnglishAgain() {
		class EnglishGoodbye {
			public static final String farewell = "Bye bye";
			public void sayGoodbye() {
				System.out.println(farewell);
			}
		}
		EnglishGoodbye myEnglishGoodbye = new EnglishGoodbye();
		myEnglishGoodbye.sayGoodbye();
	}
}

class EnglishVinglishDemo {
	public static void playWithEnglish() {
		EnglishVinglish english = new EnglishVinglish();
		// english.greetInEnglish();
		// english.sayGoodbyeInEnglish();
		english.sayGoodbyeInEnglishAgain();
	}
}


// _________________________________________________________________
// _________________________________________________________________


class GreetingAnonymousClasses {
  
	interface Greeting {
		public void greet();
		public void greetSomeone(String someone);
	}
  
	public void sayHello() {
		
		class EnglishGreeting implements Greeting {
			String name = "world";
			public void greet() {
				greetSomeone("world");
			}
			public void greetSomeone(String someone) {
				name = someone;
				System.out.println("Hello " + name);
			}
		}
	  
		Greeting englishGreeting = new EnglishGreeting();
		
		Greeting frenchGreeting = new Greeting() {
			String name = "tout le monde";
			public void greet() {
				greetSomeone("tout le monde");
			}
			public void greetSomeone(String someone) {
				name = someone;
				System.out.println("Salut " + name);
			}
		};
		
		Greeting spanishGreeting = new Greeting() {
			String name = "mundo";
			public void greet() {
				greetSomeone("mundo");
			}
			public void greetSomeone(String someone) {
				name = someone;
				System.out.println("Hola, " + name);
			}
		};
		englishGreeting.greet();
		frenchGreeting.greetSomeone("Fred");
		spanishGreeting.greet();
	}

}

class GreetingAnonymousClassesDemo {
	public static void playWithGreeting() {
		GreetingAnonymousClasses myApp =
			new GreetingAnonymousClasses();
		myApp.sayHello();
	}            
}


// _________________________________________________________________
// _________________________________________________________________


class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public Employee(String name) {
        this.name = name;
        this.salary = 0.0;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;
    }
    
    public final String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }

    public String toString() {
        return getClass().getName() + "[name=" + name
            + ",salary=" + salary + "]";
    }
}


// import java.lang.reflect.Method;
// import java.lang.reflect.Modifier;
// import java.util.Arrays;
// import java.util.Scanner;

class MethodNamePrinter {
	public static void printMethodNames() throws ReflectiveOperationException {
		System.out.print("Class name: ");

		Scanner in = new Scanner(System.in);
		String className = in.nextLine();
		
		Class<?> clazz = Class.forName( className );
		
		while (clazz != null) {

			for (Method m : clazz.getDeclaredMethods()) { 
				System.out.println(
					Modifier.toString(m.getModifiers()) + " " +
					m.getReturnType().getCanonicalName() + " " +
					m.getName() +
					Arrays.toString(m.getParameters()));                    
			}
			clazz = clazz.getSuperclass();
		}
	}
}

// Function : MethodNamePrinter.printMethodNames
// Class name: java.lang.String

// _________________________________________________________________
// _________________________________________________________________

// import java.util.ArrayList;
// import java.util.Arrays;
// import java.util.Objects;

class MethodReferenceDemo {
    public static void playWithMethodReferences() {
        String[] strings = { "Mary", "had", "a", "little", "lamb" };

        Arrays.sort(strings, String::compareToIgnoreCase );
        
        System.out.println(Arrays.toString(strings));

        ArrayList<String> list = new ArrayList<>( 
        	Arrays.asList("Malfoy", "Crabbe", "Goyle", null));
        
        list.removeIf( Objects::isNull );
        
        list.forEach( System.out::println );
    }
}

class ConstructorReferenceDemo {
    public static void playWithConstructorReference() {
        ArrayList<String> names = new ArrayList<>();
        names.add("Peter");
        names.add("Paul");
        names.add("Mary");
        
        Employee[] employees = names.stream()
        							.map( Employee::new )
        		 					.toArray( Employee[]::new );
        
        for (Employee e : employees) 
        	System.out.println(e.getName());
    }
}

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________


public class JavaClassesMore {

	public static void main( String[] args ) {
		System.out.println("\nFunction : EnumDemo.playWithEnums");
		EnumDemo.playWithEnums();

		System.out.println("\nFunction : Calculator.calculate");
		Calculator.calculate();

		System.out.println("\nFunction : LocalClassDemo.playWithLocalClass");
		LocalClassDemo.playWithLocalClass();

		System.out.println("\nFunction : StaticImportDemo.playWithStaticImport");
		StaticImportDemo.playWithStaticImport();

		System.out.println("\nFunction : NetworkDemo.playWithInnerClass");
		NetworkDemo.playWithInnerClass();

		System.out.println("\nFunction : InnerClassDemo.playWithInnerClass");
		InnerClassDemo.playWithInnerClass();

		System.out.println("\nFunction : NestedClassDemo.playWithNestedClass");
		NestedClassDemo.playWithNestedClass();

		System.out.println("\nFunction : ProfessionalDataStructureDemo.playWithDataStructure");
		ProfessionalDataStructureDemo.playWithDataStructure();

		System.out.println("\nFunction : LocalClassExampleDemo.playWithLocalClass");
		LocalClassExampleDemo.playWithLocalClass();

		System.out.println("\nFunction : EnglishVinglishDemo.playWithEnglish");
		EnglishVinglishDemo.playWithEnglish();

		System.out.println("\nFunction : GreetingAnonymousClassesDemo.playWithGreeting");
		GreetingAnonymousClassesDemo.playWithGreeting();

		System.out.println("\nFunction : MethodNamePrinter.printMethodNames");
		
		try { MethodNamePrinter.printMethodNames(); }
		catch( Exception e ) {};

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

