/*
javac JavaClassesAndLogging.java -d build
java -cp build/ learnJava.JavaClassesAndLogging
*/

package learnJava;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

import java.util.Arrays;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

// _________________________________________________________________
// _________________________________________________________________

class ThrowDemo {
	public static int randInt(int low, int high) {
		if (low > high)
			throw new IllegalArgumentException(
				"low should be <= high but low is "
				+ low + " and high is " + high);

		return low + (int)(Math.random() * (high - low + 1));
	}
	
	public static void playWithException() {
		System.out.println("Generating a random number...");
		int r = randInt(10, 20);
		System.out.println("r = " + r);
		System.out.println("And another...");
		r = randInt(10, 5);
		System.out.println("r = " + r);
	}
}

// _________________________________________________________________

class FileFormatException extends IOException {
	public FileFormatException() {}
	public FileFormatException(String message) {
		super(message);
	}
}

// _________________________________________________________________


class TryWithResourcesDemo {

	public static void print(Scanner in, PrintWriter out) {
		try (in; out) { // Effectively final variables
			while (in.hasNext())
				out.println(in.next().toLowerCase());            
		}
	}
	
	public static void playWithException() throws IOException {
		List<String> lines = List.of("Mary had a little lamb. Its fleece was white as snow.".split(" "));
		
		// Try With Resources
		//	 Within Bracket Open/Use Resource
		//		Try With Resources Will Generate finally Block
		//			With Generated Code To Close/Deallocate Resource
		try (PrintWriter out = new PrintWriter("/tmp/output1.txt")) {
			for (String line : lines) {
				out.println(line.toLowerCase());
			}
		}

		try (Scanner in = new Scanner(Paths.get("/usr/share/dict/words"));
				PrintWriter out = new PrintWriter("/tmp/output2.txt")) {
			while (in.hasNext())
				out.println(in.next().toLowerCase());
		}
		
		PrintWriter out3 = new PrintWriter("/tmp/output3.txt");
		try (out3) {
			for (String line : lines) {
				out3.println(line.toLowerCase());
			}
		}                
	}
}


// _________________________________________________________________

// import java.util.concurrent.locks.Lock;
// import java.util.concurrent.locks.ReentrantLock;

class TryFinallyDemo {
    public static Lock myLock = new ReentrantLock();
    private static int counter = 0;

    public static void playWithLockResources() throws InterruptedException{
        Thread[] threads = new Thread[2];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new Thread(() -> {
                try {
                    for (int k = 1; k <= 1000; k++) {
                        myLock.lock();
                        try {
                            counter++;
                            Thread.sleep(1);
                        } finally {
                            myLock.unlock();
                        }
                    }
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            });
        }
        for (Thread t : threads) t.start();
        
        // Try this: (1) Uncomment the line below
        // threads[0].interrupt();
        // Run the program. What happens? Why?
        // (2) Now comment out the lines try {, } finally {, }
        // Run the program. What happens? Why?
        
        for (Thread t : threads) t.join();
        System.out.println(counter);
    }
}

// _________________________________________________________________


// import java.util.Arrays;
// import java.util.Scanner;

class AssertionDemo {
    public static double[] solveQuadraticEquation(double a, double b, double c) {
        double discriminant = b * b - 4 * a * c;
        assert discriminant >= 0;
        assert a != 0 : "a == 0; not a quadradic equation";
        double discrRoot = Math.sqrt(discriminant);
        return new double[] { 
                (-b - discrRoot) / (2 * a),
                (-b + discrRoot) / (2 * a)
        };
    }
    
    public static void playWithAssert() {
        try (Scanner in = new Scanner(System.in)) {
            System.out.println("Enter a b c (e.g. 0 2 1)");
            double a = in.nextDouble();
            double b = in.nextDouble();
            double c = in.nextDouble();
            System.out.println(Arrays.toString(solveQuadraticEquation(a, b, c)));
        }
    }
}

// _________________________________________________________________

// import java.util.logging.ConsoleHandler;
// import java.util.logging.Handler;
// import java.util.logging.Level;
// import java.util.logging.Logger;

class LoggingDemo {
    public static void playWithLoggers() {
        Logger.getGlobal().info("Starting program");
        Logger.getGlobal().setLevel(Level.OFF);
        Logger.getGlobal().info("Global logger turned off");
        Logger logger = Logger.getLogger("com.horstmann.corejava");
        logger.fine("Global logger turned off");
        logger.setLevel(Level.FINE);
        logger.fine("Set logger to fine");
        logger.setUseParentHandlers(false);
        Handler handler = new ConsoleHandler();
        handler.setLevel(Level.FINE);
        logger.addHandler(handler);
        logger.fine("Configured handler");
    }
}

// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________

public class JavaExceptionsAndLogging {

	public static void main( String[] args ) {
		System.out.println("\nFunction : ThrowDemo.playWithException");
		
		try {
			ThrowDemo.playWithException();
		} catch ( IllegalArgumentException e ) {
			System.out.println("IllegalArgumentException Handled...");
		} catch ( Exception e ) {
			// Logic To Handle Exception...
			System.out.println("Exception Handled...");
		} finally {
			System.out.println("Finally...");			
		}

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

