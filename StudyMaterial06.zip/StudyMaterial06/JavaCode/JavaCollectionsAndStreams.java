/*
javac JavaCollectionsAndStreams.java -d build
java -cp build/ learnJava.JavaCollectionsAndStreams
*/

package learnJava;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import java.util.ArrayDeque;
import java.util.Queue;

import java.util.stream.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//____________________________________________________

class IteratorDemo {
    public static void playWithIterator() {
        Collection<String> coll = new ArrayList<>();
        coll.add("Peter");
        coll.add("Paul");
        coll.add("Mary");
        Iterator<String> iter = coll.iterator();
        while (iter.hasNext()) {
            String element = iter.next();
            process(element);
        }
        
        iter = coll.iterator();
        while (iter.hasNext()) {
            String element = iter.next();
            if (element.startsWith("M"))
                iter.remove();
        } 
        
        coll.removeIf(e -> e.endsWith("r"));
        for (String element : coll) 
            process(element);
    }
    
    public static void process(String s) { System.out.println("Processing " + s); }
}

//____________________________________________________

class ListIteratorDemo {
    public static void playWithListIterator() {
        List<String> friends = new LinkedList<>();
        ListIterator<String> iter = friends.listIterator();
        iter.add("Fred"); // Fred |
        iter.add("Wilma"); // Fred Wilma |
        iter.previous(); // Fred | Wilma
        iter.set("Barney"); // Fred | Barney
        System.out.println(friends);
    }
}

//____________________________________________________

class SetDemo {
    public static void playWithSet() {
        Set<String> badWords = new HashSet<>();
        badWords.add("sex");
        badWords.add("drugs");
        badWords.add("c++");
        
        Scanner in = new Scanner(System.in);
        System.out.print("Please choose a user name: ");
        String username = in.next();        
        if (badWords.contains(username.toLowerCase()))
            System.out.println("Please choose a different user name");
        else
            System.out.println("Registered " + username + " since it wasn't one of " + badWords);
        
        TreeSet<String> countries = new TreeSet<>((u, v) ->
            u.equals(v) ? 0
            : u.equals("USA") ? -1
            : v.equals("USA") ? 1
            : u.compareTo(v));
        
        countries.add("Bahrain");
        countries.add("Australia");
        countries.add("USA");
        countries.add("Canada");
        System.out.println(countries);
    }
}

//____________________________________________________

class MapDemo {
    public static void playWithMaps() {
        Map<String, Integer> counts = new HashMap<>();
        counts.put("Alice", 1); // Adds the key/value pair to the map
        counts.put("Alice", 2); // Updates the value for the key
        
        int count = counts.get("Alice");
        System.out.println(count);
        count = counts.getOrDefault("Barney", 0);
        System.out.println(count);
        
        String word = "Fred";
        counts.merge(word, 1, Integer::sum);
        counts.merge(word, 1, Integer::sum);
        System.out.println(counts.get(word));

        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            process(key, value);
        }
        
        counts.forEach((k, v) -> process(k, v));
    }
    
    public static void process(String key, Integer value) {
        System.out.printf("Processing key %s and value %d\n", key, value);
    }
        
}

//____________________________________________________

class StackQueueDemo {
    public static void playWithStackQueue() {
        ArrayDeque<String> stack = new ArrayDeque<>();
        stack.push("Peter");
        stack.push("Paul");
        stack.push("Mary");
        while (!stack.isEmpty())
            System.out.println(stack.pop());
        
        System.out.println();
        
        Queue<String> queue = new ArrayDeque<>();
        queue.add("Peter");
        queue.add("Paul");
        queue.add("Mary");
        while (!queue.isEmpty())
            System.out.println(queue.remove());
        
    }
}

//____________________________________________________


class StreamDemo {
    private static int prev;
    public static void playWithStreamFiltering() {
        Stream<Integer> values = Stream.of(1, 2, 2, 3, 3, 3, 4, 2);
        values = values.filter( x -> { 
            boolean r = prev != x; 
            prev = x; 
            return r; }
        ).peek(x -> { return; });

        values.forEach(System.out::println);
    }
}


//____________________________________________________

class CountLongWords {
    public static void playWithWordsCounting() throws IOException {
        String contents = Files.readString(Paths.get("alice.txt"));
        List<String> words = List.of(contents.split("\\PL+"));

        long count = 0;
        for (String w : words) {
            if (w.length() > 12)
                count++;
        }
        System.out.println(count);

        count = words.stream().filter(w -> w.length() > 12).count();
        System.out.println(count);

        count = words.parallelStream().filter(w -> w.length() > 12).count();
        System.out.println(count);
    }
}

//____________________________________________________


class OtherTransformations {
    public static <T> void show(String title, Stream<T> stream) {
        final int SIZE = 10;
        List<T> firstElements = stream.limit(SIZE + 1).collect(Collectors.toList());
        System.out.print(title + ": ");
        if (firstElements.size() <= SIZE)
            System.out.println(firstElements);
        else {
            firstElements.remove(SIZE);
            String out = firstElements.toString();
            System.out.println(out.substring(0, out.length() - 1) + ", ...]");
        }
    }

    public static void playWithStreamTransformations() throws IOException {
        Stream<String> uniqueWords = Stream.of("merrily", "merrily", "merrily", "gently")
                .distinct();
        show("uniqueWords", uniqueWords);

        String contents = Files.readString(Paths.get("../alice.txt"));
        List<String> words = List.of(contents.split("\\PL+"));
        show("words", words.stream());

        Stream<String> distinct =  words.stream().distinct();
        show("distinct", distinct);

        Stream<String> sorted =  words.stream().sorted();
        show("sorted", sorted);

        Stream<String> distinctSorted =  words.stream().distinct().sorted();
        show("distinctSorted", distinctSorted);

        Stream<String> longestFirst =  words.stream().sorted(Comparator.comparing(String::length).reversed());
        show("longestFirst", longestFirst);
        
        Object[] powers = Stream.iterate(1.0, p -> p * 2)
                .peek(e -> System.out.println("Fetching " + e)).limit(20).toArray();
        System.out.println(Arrays.toString(powers));
    }
}

//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________

public class JavaCollectionsAndStreams {

	public static void main( String[] args ) {
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		System.out.println("\nFunction : StreamDemo.playWithStreamFiltering");
		StreamDemo.playWithStreamFiltering();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}
