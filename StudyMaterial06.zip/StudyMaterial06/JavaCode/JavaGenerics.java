/*
javac JavaGenerics.java -d build
java -cp build/ learnJava.JavaGenerics
*/

package learnJava;

import java.io.PrintStream;
import java.util.ArrayList;

import java.lang.Exception;
import java.io.FileNotFoundException;
import java.util.function.Predicate;

//____________________________________________________

class StackInt {
	static final int MAX_SIZE = 100;
	int[] data;

	public boolean push( int data ){
		// Add Data At The Top Of The Stack
		// Return Success/Failure
		return true;
	}

	public int pop() {
		// Remove Item At The Top Of The Stack
		// Adjust Top

		// Return Popped Item
		return 10;
	}
}


class StackString {
	static final int MAX_SIZE = 100;
	String[] data;

	public boolean push( String data ){
		// Add Data At The Top Of The Stack
		// Return Success/Failure
		return true;
	}

	public String pop() {
		// Remove Item At The Top Of The Stack
		// Adjust Top

		// Return Popped Item
		return "India";
	}
}

class StackDouble {
	static final int MAX_SIZE = 100;
	double[] data;

	public boolean push( double data ){
		// Add Data At The Top Of The Stack
		// Return Success/Failure
		return true;
	}

	public double pop() {
		// Remove Item At The Top Of The Stack
		// Adjust Top

		// Return Popped Item
		return 0.0;
	}
}

//____________________________________________________

// Generics In Java Or Templates In C++
// 		Generics Is A Code To Generate Code

// T Is Type Placeholder
//		WIll Get Substituted By Compiler Based On Usage

// Polymorphic Code : Compile Time Polymorphism
class Stack<T> {
	// static final T MAX_SIZE = 100;
	T[] data;

	public boolean push( T data ){
		// Add Data At The Top Of The Stack
		// Return Success/Failure
		return true;
	}

	public void pop() {
		// Remove Item At The Top Of The Stack
		// Adjust Top

		// Return Popped Item
		// return 10;
		// T top
		// return top;
	}
}

// Stack<Integer> stackInteger = new Stack<Integer>();
// Stack<String> stackString = new Stack<String>();

//Compiler Will Generate Following Code
class StackInteger {
	// static final T MAX_SIZE = 100;
	Integer[] data;

	public boolean push( Integer data ){
		// Add Data At The Top Of The Stack
		// Return Success/Failure
		return true;
	}

	public void pop() {
		// Remove Item At The Top Of The Stack
		// Adjust Top

		// Return Popped Item
		// return 10;
		// T top
		// return top;
	}
}

//____________________________________________________

class Entry<K, V> {
	private K key;
	private V value;

	public Entry(K key, V value) {
		this.key = key;
		this.value = value;
	}

	public K getKey() 	{ return key; 	}
	public V getValue() { return value; }
}

class EntryDemo {
	public static void playWithGenericEntry() {
		Entry<Integer, String> entry1 = new Entry<Integer, String>(10, "Hello");
		System.out.println( entry1.getKey() );
		System.out.println( entry1.getValue() );

		Entry<String, String> entry2 = new Entry<String, String>("Ding", "Dong");
		System.out.println( entry2.getKey() );
		System.out.println( entry2.getValue() );
	}
}

 
//____________________________________________________


class ArrayUtil {
	// Utility Function Using Generic Function
	public static <T> void swap( T[] array, int i, int j) {
		T temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}

	// public static <T> T[] void swap( int i, int j, T... values ) {
	// 	T temp = array[i];
	// 	array[i] = array[j];
	// 	array[j] = temp;

	// 	return values;
	// }

}

class ArrayUtilDemo {
	public static void playWithUtilityFunctions() {
		String[] friends = {"Gabbar Singh", "Sambha", "Kalia", "Uncle Bob" };

		for ( String friend : friends ) { System.out.println( friend );	 }
		ArrayUtil.swap( friends, 0, 1 );
		for ( String friend : friends ) { System.out.println( friend );	 }

		Integer[] numbers = { 100, 200, 300, 900 };
		for ( Integer number : numbers ) { System.out.println( number );	 }
		ArrayUtil.swap( numbers, 0, 1 );
		for ( Integer number : numbers ) { System.out.println( number );	 }
	}
}


//____________________________________________________

class Closeables {
	// T Placeholder Can Have Bounds
	public static < T extends AutoCloseable > void closeAll( ArrayList<T> elements) throws Exception {
		for ( T element : elements ) {
			element.close();
		}
	}
}

class ClosablesDemo {
	public static void playWithCloseables() throws Exception {
		PrintStream p1 = new PrintStream("./wordsList1.txt");
		PrintStream p2 = new PrintStream("./wordsList2.txt");	
		ArrayList< PrintStream > printStream = new ArrayList<>();
		printStream.add( p1 );
		printStream.add( p2 );
		try {
			Closeables.closeAll( printStream );
		} catch ( Exception e ) { System.out.println("Exception Caught..."); }

		ArrayList< String > stringSteam = new ArrayList<>();
		stringSteam.add(" Ding ");
		stringSteam.add(" Dong ");
		// try {
		// 	Closeables.closeAll( stringSteam );
		// } catch ( Exception e ) { System.out.println("Exception Caught..."); }
	}
}

//____________________________________________________

class ArrayUtilAgain {
	public static <T> void printAll( T[] elements, Predicate< ? super T > filter) {
		for ( T element: elements ) {
			if( filter.test( element )) { 
				System.out.println( element.toString() );
			}
		}
	}
}

class ArrayUtilAgainDemo {
	public static void playWithPrintAll() {
		ArrayUtilAgain utility = new ArrayUtilAgain();

		// ArrayList< String > names = new ArrayList<>();
		// names.add("Gabbar Singh");
		// names.add("Sambha");
		// names.add("Kalia");
		// utility.printAll( names, null );

		String[] friends1 = {"Gabbar Singh", "Sambha", "Kalia", "Gobby" };
		utility.printAll( friends1, name -> name.startsWith("G")  );

		String[] friends2 = {"Gabbar Singh", "Sambha", null, "Kalia", "Gobby", null };
		utility.printAll( friends2, name -> name != null  );

	}
}

//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________

public class JavaGenerics {

	public static void main( String[] args ) {
		System.out.println("\nFunction : EntryDemo.playWithGenericEntry");
		EntryDemo.playWithGenericEntry();

		System.out.println("\nFunction : ArrayUtilDemo.playWithUtilityFunctions");
		ArrayUtilDemo.playWithUtilityFunctions();

		System.out.println("\nFunction : ClosablesDemo.playWithCloseables");
		try { ClosablesDemo.playWithCloseables(); }
		catch( Exception e ) { System.out.println("Exception Found..."); }

		System.out.println("\nFunction : ArrayUtilAgainDemo.playWithPrintAll");
		ArrayUtilAgainDemo.playWithPrintAll();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}
