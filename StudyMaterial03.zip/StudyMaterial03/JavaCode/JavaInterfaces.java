/*
javac JavaInterfaces.java -d build
java -cp build/ learnJava.JavaInterfaces
*/

package learnJava;

//____________________________________________________

// Defines What To Do
interface IntSequence {
    boolean hasNext();
    int next();
}

// Defines How/When/Where/Which Way etc.. To Do
class DigitSequence implements IntSequence {
    private int number;

    public DigitSequence(int n) {
        number = n;
    }

    public boolean hasNext() {
        return number != 0;
    }

    public int next() {
        int result = number % 10;
        number /= 10;
        return result;
    }
    
    public int rest() {
        return number;
    }
}

class SquareSequence implements IntSequence {
    private int i;

    public boolean hasNext() {
        return true;
    }

    public int next() {
        i++;
        return i * i;
    }
}

class IntSequenceDemo {
    public static double average(IntSequence seq, int n) {
        int count = 0;
        double sum = 0;
        while (seq.hasNext() && count < n) {
            count++;
            sum += seq.next();
        }
        return count == 0 ? 0 : sum / count;
    }

    public static void playWithInterfaces() {
        SquareSequence squares = new SquareSequence();
        double avg = average(squares, 100);
        System.out.println("Average of first 100 squares: " + avg);
        
        IntSequence digits = new DigitSequence(1729);
        while (digits.hasNext()) 
        	System.out.print(digits.next() + " ");
        System.out.println();
        
        digits = new DigitSequence(1729);
        avg = average(digits, 100);
            // Will only look at the first four sequence values
        System.out.println("Average of the digits: " + avg);
    }
}

//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________

public class JavaInterfaces {

	public static void main( String[] args ) {
 		System.out.println("\nFunction : playWithInterfaces");
 		IntSequenceDemo.playWithInterfaces();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
 		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}
