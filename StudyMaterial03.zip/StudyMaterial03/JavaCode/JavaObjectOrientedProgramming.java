/*
javac JavaObjectOrientedProgramming.java -d build
java -cp build/ learnJava.JavaObjectOrientedProgramming
*/

package learnJava;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Random;

//____________________________________________________
// HOME WORK
//____________________________________________________

class Cal {
    public void useDateAndTime( String[] args ) {
        LocalDate date = LocalDate.now().withDayOfMonth(1);
        int month;
        if (args.length >= 2) {        
            month = Integer.parseInt(args[0]);
            int year = Integer.parseInt(args[1]);
            date = LocalDate.of(year, month, 1);
        } else {
            month = date.getMonthValue();
        }
        
        System.out.println(" Mon Tue Wed Thu Fri Sat Sun");
        DayOfWeek weekday = date.getDayOfWeek();
        int value = weekday.getValue(); // 1 = Monday, ... 7 = Sunday
        for (int i = 1; i < value; i++) 
            System.out.print("    ");
        while (date.getMonthValue() == month) {
            System.out.printf("%4d", date.getDayOfMonth());
            date = date.plusDays(1);
            if (date.getDayOfWeek().getValue() == 1) 
                System.out.println();
        }
        if (date.getDayOfWeek().getValue() != 1) 
           System.out.println();
    }
}

//____________________________________________________

class Employee {
	// Best Practice
	//		Encapulate State and Make State Private
    private String name;
    private double salary;
    // Definition of Constructor
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

 class EmployeeDemo {
    public static void playWithEmployee() {
    					// Invoking Constructor
        Employee fred = new Employee("Fred", 50000);
        // Sending raiseSalary Message With Payload 10 
        //		To Object fred
        fred.raiseSalary(10);
        System.out.println(fred.getName());
        System.out.println(fred.getSalary());
    }
}

//____________________________________________________


class Employee1 {
	// BEST PRACTICE
	//		Must Initialise All The Member State
	//			To Legal State
    private String name = ""; // Default Values
    private double salary;
    private final int id;
        
    { // An initialization block
        Random generator = new Random(); 
        id = 1 + generator.nextInt(1_000_000);
    }
    
    public Employee1(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    
    public Employee1(double salary) {
        // name already set to ""
        this.salary = salary;
    }        
    
    public Employee1(String name) {
        // salary automatically set to zero
        this.name = name;
    } 
    
    public Employee1() {
        this("", 0);
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }
}

//_______________________________________________________________________________________

class EmployeeDemo1 {
    public static void playWithEmployee1() {
        Employee1 james = new Employee1("James Bond", 500000);

        System.out.println(james.getName());
        System.out.println(james.getSalary());

            // calls Employee(String, double) constructor
        Employee1 anonymous = new Employee1("", 40000);
        System.out.println(anonymous.getName());
        System.out.println(anonymous.getSalary());        
            // calls Employee(double) constructor
        Employee1 unpaid = new Employee1("Igor Intern");
        System.out.println(unpaid.getName());
        System.out.println(unpaid.getSalary());

        Employee1 e = new Employee1();
            // no-arg constructor
    
        System.out.println(e.getName());
        System.out.println(e.getSalary());
    }
}


//____________________________________________________


class Employee2 {
    private static int lastId = 0;
    private int id; 
    private String name;
    private double salary;
        
    public Employee2() {
        lastId++;
        id = lastId;
    }
    
    // BEST PRACTICE
    ///		Constructor Should Do Only Initialitions
    public Employee2(String name, double salary) {
        this();
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }
}

class EmployeeDemo2 {
    public static void playWithEmployee2() {
        Employee2 gabbar = new Employee2("Gabbar Singh", 500000);
        System.out.println(gabbar.getId());
        System.out.println(gabbar.getName());
        System.out.println(gabbar.getSalary());

            // calls Employee(String, double) constructor
        Employee2 sambha = new Employee2("Sambha", 1000);
        System.out.println(sambha.getId());
        System.out.println(sambha.getName());
        System.out.println(sambha.getSalary());

            // calls Employee(double) constructor
        Employee2 kalia = new Employee2("Kalia", 2000);
        System.out.println(kalia.getId());
        System.out.println(kalia.getName());
        System.out.println(kalia.getSalary());

        Employee2 thakur = new Employee2("Thakur", 999999999);
            // no-arg constructor
        System.out.println(thakur.getId());    
        System.out.println(thakur.getName());
        System.out.println(thakur.getSalary());
    }
}

//____________________________________________________

class MembersDemo {
	// Instance/Object Member
	public String some = "Someone!";
	// Class/Type Member
	static public String staticSome = "Static Some";

	// Instance/Object Member
	public void accessMembers() {
		System.out.println(some);
		System.out.println(staticSome);
	}

	public void nonStaticMethod() {
		System.out.println("Instance/Object Method Called...");
		// staticMethod();
	}

	static public void staticMethod() {
		System.out.println("Class/Type Method Called...");
		nonStaticMethod();
	}

    // public static void staticMemberFunction() {
    //     int dieToss = 
    //     System.out.println(); // Prints 10%
    // }
}

//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________

public class JavaObjectOrientedProgramming {

	public static void playWithCal(String[] args) {
		Cal cal = new Cal();
		cal.useDateAndTime(args);
	}

	public static void playWithMembers() {
		MembersDemo member = new MembersDemo();
		member.accessMembers();

		// Class and Instance Members Both Accessed Using Object/Instance
		System.out.println( member.some );
		// Bad Programming Practice
		//		Don't Access Class Members Using Instance/Object
		System.out.println( member.staticSome );

		// System.out.println( MembersDemo.some ); // Not A Class Member 
		System.out.println( MembersDemo.staticSome );
	
		member.nonStaticMethod();
		// Bad Programming Practice
		//		Don't Access Class Members Using Instance/Object
		member.staticMethod();

		// MembersDemo.nonStaticMethod(); // Not A Class/Type Member
		MembersDemo.staticMethod();
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction : playWithCal");
		playWithCal(args);

		System.out.println("\nFunction : playWithEmployee");
		EmployeeDemo.playWithEmployee();

		System.out.println("\nFunction : playWithEmployee1");
		EmployeeDemo1.playWithEmployee1();

		System.out.println("\nFunction : playWithEmployee2");
		EmployeeDemo2.playWithEmployee2();
		
		System.out.println("\nFunction : playWithMembers");
		playWithMembers();

 		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
 		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}
