
package learnJava;

interface Superpower {
	public void fly(); 		
	public void saveWorld();
}

class BadSpiderman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Spiderman!"); 		}
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

class Spiderman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Spiderman!"); 		}
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

class Superman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Superman!"); 		}
	public void saveWorld() { System.out.println("Save World Like Superman!");  }
}

class Heman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Heman!"); 		}
	public void saveWorld() { System.out.println("Save World Like Heman!"); }
}

class WonderWoman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like WonderWoman!"); 		  }
	public void saveWorld() { System.out.println("Save World Like WonderWoman!"); }	
}

// Using Inheritance
class Human extends BadSpiderman {
// class Human extends Superman {
// class Human1 extends Heman {
	public void fly() 		{ super.fly(); 		 }
	public void saveWorld() { super.saveWorld(); }
	// public void fly() 		{ System.out.println("Fly Like Human!"); 		}
	// public void saveWorld()  { System.out.println("Save World Like Human!"); }
}

// Using Composition/Embedding
class Human2 {
	// Spiderman spiderman = new Spiderman();
	// Superman power = new Superman();
	Heman power = new Heman();
	public void fly() 		{ power.fly(); 		 }
	public void saveWorld() { power.saveWorld(); }
	// public void fly() 		{ System.out.println("Fly Like Human!"); 		}
	// public void saveWorld()  { System.out.println("Save World Like Human!"); }
} 

// BetterHuman Is Polymorphic 
// Using Composition/Embedding
class BetterHuman {
	// Spiderman spiderman = new Spiderman();
	// Superman power = new Superman();
	// Heman power = new Heman();
	Superpower power = null;
	public void fly() 		{ if (power != null ) power.fly();   	 }
	public void saveWorld() { if (power != null ) power.saveWorld(); }
	// public void fly() 		{ System.out.println("Fly Like Human!"); 		}
	// public void saveWorld()  { System.out.println("Save World Like Human!"); }
}

public class HumanDemo {
	public static void main( String[] args ) {
		Human1 human1 = new Human1();
		human1.fly();
		human1.saveWorld();

		Human2 human2 = new Human2();
		human2.fly();
		human2.saveWorld();

		BetterHuman human = new BetterHuman();
		human.power = new BadSpiderman();
		human.fly();
		human.saveWorld();

		human.power = new Spiderman();
		human.fly();
		human.saveWorld();

		human.power = new Superman();
		human.fly();
		human.saveWorld();

		human.power = new Heman();
		human.fly();
		human.saveWorld();

		human.power = new WonderWoman();
		human.fly();
		human.saveWorld();
	}
}
