/*
javac JavaClassesAndLogging.java -d build
java -cp build/ learnJava.JavaClassesAndLogging
*/

package learnJava;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

// _________________________________________________________________
// _________________________________________________________________

class ThrowDemo {
	public static int randInt(int low, int high) {
		if (low > high)
			throw new IllegalArgumentException(
				"low should be <= high but low is "
				+ low + " and high is " + high);

		return low + (int)(Math.random() * (high - low + 1));
	}
	
	public static void playWithException() {
		System.out.println("Generating a random number...");
		int r = randInt(10, 20);
		System.out.println("r = " + r);
		System.out.println("And another...");
		r = randInt(10, 5);
		System.out.println("r = " + r);
	}
}

// _________________________________________________________________

class FileFormatException extends IOException {
	public FileFormatException() {}
	public FileFormatException(String message) {
		super(message);
	}
}

// _________________________________________________________________


class TryWithResourcesDemo {

	public static void print(Scanner in, PrintWriter out) {
		try (in; out) { // Effectively final variables
			while (in.hasNext())
				out.println(in.next().toLowerCase());            
		}
	}
	
	public static void playWithException() throws IOException {
		List<String> lines = List.of("Mary had a little lamb. Its fleece was white as snow.".split(" "));
		
		// Try With Resources
		try (PrintWriter out = new PrintWriter("/tmp/output1.txt")) {
			for (String line : lines) {
				out.println(line.toLowerCase());
			}
		}

		try (Scanner in = new Scanner(Paths.get("/usr/share/dict/words"));
				PrintWriter out = new PrintWriter("/tmp/output2.txt")) {
			while (in.hasNext())
				out.println(in.next().toLowerCase());
		}
		
		PrintWriter out3 = new PrintWriter("/tmp/output3.txt");
		try (out3) {
			for (String line : lines) {
				out3.println(line.toLowerCase());
			}
		}                
	}
}


// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________

public class JavaExceptionsAndLogging {

	public static void main( String[] args ) {
		System.out.println("\nFunction : ThrowDemo.playWithException");
		
		try {
			ThrowDemo.playWithException();
		} catch ( IllegalArgumentException e ) {
			System.out.println("IllegalArgumentException Handled...");
		} catch ( Exception e ) {
			// Logic To Handle Exception...
			System.out.println("Exception Handled...");
		} finally {
			System.out.println("Finally...");			
		}

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

