/*
javac JavaInheritance.java -d build
java -cp build/ learnJava.JavaInheritance
*/

package learnJava;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.Random;

// _________________________________________________________________
// _________________________________________________________________


class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;
    }
    
    public final String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }

    public String toString() {
        return getClass().getName() + "[name=" + name
            + ",salary=" + salary + "]";
    }
}


class Manager extends Employee {
    private double bonus;
    
    public Manager(String name, double salary) {
        super(name, salary);
        bonus = 0;
    }
    
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    
    @Override
    public double getSalary() { // Overrides superclass method
        return super.getSalary() + bonus;
    }
} 


class EmployeeDemo {
	public static void playWithEmployee() {
		Employee gabbar = new Employee( "Gabbar Singh", 50000.0 );
		System.out.println( gabbar );

		Employee sambha = new Employee( "Aaare O Sambha", 500.0 );
		System.out.println( sambha );
	}
}
// _________________________________________________________________



// class NewArrayList<String> extends ArrayList<String> {

//             public void add(int index, String element) {
//                 super.add(index, element);
//                 System.out.printf("Adding %s at %d\n", element, index);
//             }
//  };

class AnonymousSubclassDemo {
    public static void playWithAnonymousSubclass() {

        ArrayList<String> names = new ArrayList<String>(100) {            
            public void add(int index, String element) {
                super.add(index, element);
                System.out.printf("Adding %s at %d\n", element, index);
            }
        };
        
 		// Compiler Will Generate Following Code For Above Lines

		// class TempArrayList<String> extends ArrayList<String> {
  //           public void add(int index, String element) {
  //               super.add(index, element);
  //               System.out.printf("Adding %s at %d\n", element, index);
  //           }
		//  };

  //       TempArrayList<String> names = new TempArrayList<String>(100) 


        names.add(0, "Peter");
        names.add(1, "Paul");
        names.add(0, "Mary");
        System.out.println(names);
        
        invite( new ArrayList<String>() {{ add("Harry"); add("Sally"); }} );
    }
    
    public static void invite(ArrayList<String> friends) {
        System.out.println("Guest list: " + friends);
    }
}

// _________________________________________________________________

// import java.util.Objects;

// class Item extends Object {
class Item {
    private String description;
    private double price;
        
    public Item(String description, double price) {
        this.description = description;
        this.price = price;
    }

    public boolean equals(Object otherObject) {
        // A quick test to see if the objects are identical
        // System.out.println( this == otherObject );
        if (this == otherObject) return true;
        // Must return false if the explicit parameter is null
        
        // System.out.println(otherObject == null);
        if (otherObject == null) return false;
        // Check that otherObject is a Item
        
        // System.out.println( getClass() != otherObject.getClass() );
        if (getClass() != otherObject.getClass()) return false;
        // Test whether the instance variables have identical values
        Item other = (Item) otherObject;

        // System.out.println( Objects.equals(description, other.description) );
        // System.out.println( price == other.price );
        return Objects.equals(description, other.description)
            && price == other.price;
    }
    
    public int hashCode() {
        return Objects.hash(description, price);
    }
}

class ItemDemo {
	public static void playWithItems() {
		Item soap1 = new Item("Rexona", 50.0);
		Item soap2 = new Item("Rexona", 50.0);

		// == Operator Will Compare Only References
		// 		It Doesn;t Maps To soap1.equals( soap2 );
		System.out.println( soap1 == soap2 ); 
		System.out.println( soap1.equals( soap2 ) );
	}
}

// _________________________________________________________________

class DiscountedItem extends Item {
    private double discount;

    public DiscountedItem(String description, double price, double discount) {
        super(description, price);
        this.discount = discount;
    }

    public boolean equals(Object otherObject) {
        if (!super.equals(otherObject)) return false;
        DiscountedItem other = (DiscountedItem) otherObject;
        return discount == other.discount;
    }
    
    public int hashCode() {
        return Objects.hash(super.hashCode(), discount);
    }
}


// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________
// _________________________________________________________________


public class JavaInheritanceAndReflections {

	public static void main( String[] args ) {
		System.out.println("\nFunction : ItemDemo.playWithItems");
		ItemDemo.playWithItems();

		System.out.println("\nFunction : EmployeeDemo.playWithEmployee ");
		EmployeeDemo.playWithEmployee();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

