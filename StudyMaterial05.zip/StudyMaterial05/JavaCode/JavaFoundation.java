/*
javac JavaFoundation.java -d build
java -cp build/ learnJava.JavaFoundation 
*/

package learnJava;

import java.util.Random;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Scanner;

// package learnJava.java;

class ImportDemo {
	public void playWithRandom() {
		// Creating Object/Instance Of Random Class Type
		Random random = new Random();

		//	Invoing random Member Functions/Methods
		System.out.println( random.nextInt() );
		System.out.println( random.nextInt() );
		System.out.println( random.nextInt() );
	}
}

class NumberDemo {
	public static int sum(int x, int y) {
		int result = x + y;
		return result;
	}

	public static int summation( int a, int b ) {
		int result = 0;

		if( (( b > 0 ) && ( a > ( Integer.MAX_VALUE - b ) ))  ||
			(( b < 0 ) && ( a < ( Integer.MIN_VALUE - b ) )) ) {
			System.out.printf("\nCan't Calulate Sum For Given a And b");
		} else {
			result = a + b;
		}

		return result;
	}

	public static void playWithSum() {
		int a = 0, b = 0, result = 0;

		a = 2147483647;
		b = 1;
		result = sum( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : -2147483648

		a = -2147483648;
		b = -1;
		result = sum( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : 2147483647
	}

	public static void playWithSummation() {
		int a = 0, b = 0, result = 0;

		a = 2147483647;
		b = 1;
		result = summation( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : -2147483648

		a = -2147483648;
		b = -1;
		result = summation( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : 2147483647
	}

	public static void playWithNumbers() {
        // System.out.println(4000000000); // long literal
        System.out.println(4000000000L); // long literal
        System.out.println(0xCAFEBABE); // hex literal
        System.out.println(0b1001); // binary literal
        System.out.println(011); // octal literal
        
        // Underscores in literals   
        System.out.println(1_000_000_000); 
        System.out.println(0b1111_0100_0010_0100_0000);
	
        System.out.println( 900 );
        System.out.println( 900.90 );        // Double Type
        System.out.println( 900.90D );       // Double Type
        System.out.println( 900.90F );        

        // try {
        System.out.println(1.0 / 0.0); 
        System.out.println(-1.0 / 0.0);
        System.out.println(0.0 / 0.0);
        // catch( ) {} // Won't Work...
		// Infinity
		// -Infinity
		// NaN

        // Throws The Exception
        // 		java.lang.ArithmeticException
        // System.out.println( 0 / 0 );
        System.out.println(1.0 / 0.0  == Double.POSITIVE_INFINITY ) ; 
        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY );
        System.out.println(0.0 / 0.0 == Double.NaN );
  		// true
		// true
		// false

        System.out.println( Double.isFinite( 1.0 / 0.0 ) ) ; 
        System.out.println( Double.isFinite( 1.0 / 0.0 ) ) ; 
        System.out.println( Double.isInfinite( -1.0 / 0.0 ) ) ; 
        System.out.println( Double.isInfinite( -1.0 / 0.0 ) ) ; 
        System.out.println( Double.isNaN( 0.0 / 0.0 ) );

       System.out.println(2.0 - 1.1);
       // System.out.println( (2.0 - 1.1) - 0.9 <= EPISOLN );
        
        // Character literals
        System.out.println('J'); 
        System.out.println('J' == 74); 
        System.out.println('\u004A'); 
        System.out.println('\u263A'); 
 
	}
}

class VariablesDemo {
	// Immutable/Constant
	public static final int DAYS_PER_YEAR = 365;

	// Creating New Type Having Name Weekday
	enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN };

	public static void createVariables() {
		int total = 99;
		int i = 0, count;

		Random generator = new Random();
// Random *generator = ( Random * ) malloc( sizeof( Random))

		double lotus = 90.90;

		double elevation = 0.0;
		String animal = "Elephant";

		// Creating Constant/Immutable
		final int DAY_PER_WEEK = 7;
		Weekday startDay = Weekday.MON;

		total = 111;
		System.out.println( "Total : " + total );
		// DAY_PER_WEEK = 10;

		// startDay = "TUESDAY";

		// total = "Ding Dong";
	}
}

class StringDemo {

	public static void createStrings() {
		String location = "Bangalore";
// 		String location = new String("Bangalore");
//		String *location = (String *) malloc( sizeof(String));		

		String greeting = "Hello " + location;

		System.out.println( greeting );

		location = location + " " + 560001;
		System.out.println( location );
	
		String names = String.join("Alice", "Bob", "Rinki", "Renu");
		System.out.println( names );

		location = "Delhi";
		System.out.println( location );

		// location[0] = 'T';
	
		StringBuilder builder = new StringBuilder();

		for( String zone : ZoneId.getAvailableZoneIds()) {
			builder.append( zone );
			builder.append( " : ");
		}

		String result = builder.toString();
		System.out.println( result );

		System.out.println();
		System.out.println( result.substring(0, 100));
	
		System.out.println( location.equals("Delhi"));
		System.out.println( location == "Delhi" ); // location.equals("Delhi")

		// Unicode
        String javatm = "Java\u2122";
        System.out.println(javatm);
        System.out.println(Arrays.toString(javatm.codePoints().toArray()));
        System.out.println(javatm.length());

        String octonions = "\ud835\udd46";
        System.out.println(octonions);
        System.out.println(Arrays.toString(octonions.codePoints().toArray()));
        System.out.println(octonions.length()); // Counts code units, not Unicode code points

        String chinese = "早上好";
		System.out.println(chinese);
        System.out.println(Arrays.toString(chinese.codePoints().toArray()));
        System.out.println(chinese.length()); // Counts code units, not Unicode code points
	}
}

 class InputDemo {
    public static void takeUserInput() {
        Scanner in = new Scanner( System.in );
        System.out.println("What is your name?");
        String name = in.nextLine();
        System.out.println("How old are you?");

        if (in.hasNextInt()) {
            int age = in.nextInt();
            System.out.printf("Hello, %s. Next year, you'll be %d.\n", name, age + 1);
        } else {
            System.out.printf("Hello, %s. Are you too young to enter an integer?", name);
        }
    }
}


class ArrayDemo {
    public static void createArrays() {
        String[] names = new String[10];

        for (int i = 0; i < names.length / 2; i++) {
            names[i] = "";
        }

        names[0] = "Fred";
        names[1] = names[0];
        System.out.println("names="+Arrays.toString(names));
     
     	String greeting = null;
     	System.out.println( greeting );

// Following Both Lines Are Equivalent
        int[] primes = { 17, 19, 23, 29, 31 };
        primes = new int[] { 2, 3, 5, 7, 11, 13 };
//	int ** primes = (int **) malloc( sizeof(int *) x 6 );
        System.out.println("primes=" + Arrays.toString(primes));
	 	
	 	// By Default 
	 	// Shallow Copy Or Reference Assignment
	 	int[] numbers = primes;
        System.out.println("numbers=" + Arrays.toString(numbers));
	 	numbers[5] = 100;
        System.out.println("numbers=" + Arrays.toString(numbers));
  		System.out.println("primes=" + Arrays.toString(primes));

  		primes[5] = 13;
  		System.out.println("primes=" + Arrays.toString(primes));

  		// Deep Copy i.e Coping Full Object
  		int[] copiedPrimes = Arrays.copyOf( primes, primes.length );
		System.out.println("copiedPrimes=" + Arrays.toString(copiedPrimes));
		copiedPrimes[5] = 71;
  		System.out.println("primes=" + Arrays.toString(primes));
		System.out.println("copiedPrimes=" + Arrays.toString(copiedPrimes));

	 }
}

 class ArrayListDemo {
    public static void createArrayLists() {
        ArrayList<String> friends = new ArrayList<>();
        friends.add("Peter");
        friends.add("Paul");
        friends.remove(1);
        friends.add(0, "Paul"); // Adds before index 0
        System.out.println("friends=" + friends);
        String first = friends.get(0);
        System.out.println("first=" + first);
        friends.set(1, "Mary");
        for (int i = 0; i < friends.size(); i++) {
            System.out.println(friends.get(i));
        }

        ArrayList<String> people = friends;
        people.set(0, "Mary"); // now friends.get(0) is also "Mary"
        System.out.println("people =" + people);
        System.out.println("friends=" + friends);

        ArrayList<String> copiedFriends = new ArrayList<>(friends);
        copiedFriends.set(0, "Fred"); // doesn't change friends
        System.out.println("copiedFriends=" + copiedFriends);
        System.out.println("friends=" + friends);

    }       
 }

class TwoDimensionalArrayDemo {

    public static void create2DArrays() {
        int[][] square = {
                { 16, 3, 2, 13 },
                { 3, 10, 11, 8 },
                { 9, 6, 7, 12 },
                { 4, 15, 14, 1}
            };

        System.out.println( Arrays.deepToString( square ));

        int[] temp = square[0];
        square[0] = square[1];
        square[1] = temp;

        System.out.println( Arrays.deepToString( square ));
	
        int n = 5;
        int[][] triangle = new int[n][];
        for (int i = 0; i < n; i++) {
            triangle[i] = new int[i + 1];
            triangle[i][0] = 1;
            triangle[i][i] = 1;
            for (int j = 1; j < i; j++) {
                triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
            }
        }

        // Indexing Loops
        for (int r = 0; r < triangle.length; r++) {
            for (int c = 0; c < triangle[r].length; c++) {
                System.out.printf("%4d", triangle[r][c]);
            }
            System.out.println();
        }

        // BEST PRACTICE
        //		Always Prefer Enumeration Loop Over Indexing Loop
        // Enumeration Loop
        for (int[] row : triangle) {
            for (int element : row) {
               System.out.printf("%4d", element);
            }
            System.out.println();
        }

	}
}

class VarargsDemo {

    public static double average(double... values) {
        double sum = 0;
        for (double v : values) sum += v;
        return values.length == 0 ? 0 : sum / values.length;
    }    
    
    // BEST PRACTICE
    //		Varidiac Arguments Must Be Last In Function
    //		Fixed Arguments Are Compulsory Arguments
    //		Varidiac Arguments Are Optional Arguments
    //		Hence Compulory Arguments Should Be Proceeded Before Optional Arguments
    public static double max(double first, double... rest) {
        double result = first;
        for (double v : rest) result = Math.max(v, result);
        return result;
    }
    
    public static void useVaridiacArguments() {
        int n = 42;
        System.out.printf("%d\n", n);
        System.out.printf("%d %s\n", n, "widgets");
        
        double[] scores = { 3, 4.5, 10, 0 };
        double avg = average(scores);
        System.out.println(avg);

         avg = average();
        System.out.println(avg);

         avg = average(10);
        System.out.println(avg);

         avg = average(10, 20);
        System.out.println(avg);

         avg = average(10, 20, 30);
        System.out.println(avg);

         avg = average(10, 20, 30, 40);
        System.out.println(avg);

        double largest = max(3, 4.5, 10, 0);
        System.out.println(largest);
            // average() returns 0, but max() doesn't compile
    }
}

public class JavaFoundation {
	public static void playWithImportDemo() {
		ImportDemo importDemo = new ImportDemo();
		importDemo.playWithRandom();
	}

	public static void playWithNumberDemo() {
		NumberDemo.playWithSum();
		NumberDemo.playWithSummation();
		NumberDemo.playWithNumbers();
	}

	public static void playWithVariableDemo() {
		VariablesDemo.createVariables();
	}

	public static void playWithBigNumbers() {
        BigInteger n = BigInteger.valueOf(876543210123456789L);
        BigInteger k = new BigInteger("9876543210123456789");
        BigInteger r = BigInteger.valueOf(5).multiply(n.add(k)); // r = 5 * (n + k)
        System.out.println(r);
        System.out.println(2.0 - 1.1);
        BigDecimal d = BigDecimal.valueOf(2, 0).subtract(BigDecimal.valueOf(11, 1));
        System.out.println(d);
	}

	public static void playWithStrings() {
		StringDemo.createStrings();
	}

	public static void playWithUserInputs() {
		InputDemo.takeUserInput();
	}

	public static void playWithArrays() {
		ArrayDemo.createArrays();
	}
	
	public static void playWithArrayLists() {
		ArrayListDemo.createArrayLists();
	}

	public static void playWithCommandLineArguments(String[] args) {
		for( int i = 0; i < args.length ; i++ ) {
			System.out.println(args[i]);

			String arg = args[i];
			if( arg.equals("-h") ) arg = "Hello!";
			else if( arg.equals("-g")) arg = "Good Morning!!!";
		
			System.out.println( arg );
		}

	}

	public static void playWithTwoDimentionalArrays() {
		TwoDimensionalArrayDemo.create2DArrays();
	}

	public static void playWithVaridiacArguments() {
		VarargsDemo.useVaridiacArguments();
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction : playWithImportDemo"); 
		playWithImportDemo();

		System.out.println("\nFunction : playWithNumberDemo");
		playWithNumberDemo();

		System.out.println("\nFunction : playWithVariableDemo");
		playWithVariableDemo();

		System.out.println("\nFunction : playWithBigNumbers");
		playWithBigNumbers();

		System.out.println("\nFunction : playWithStrings");
		playWithStrings();

		// System.out.println("\nFunction : playWithUserInputs");
		// playWithUserInputs(); 

		System.out.println("\nFunction : playWithArrays");
		playWithArrays();

		System.out.println("\nFunction : playWithArrayLists");
		playWithArrayLists();

		System.out.println("\nFunction : playWithCommandLineArguments");
		playWithCommandLineArguments(args);

		System.out.println("\nFunction : playWithTwoDimentionalArrays");
		playWithTwoDimentionalArrays();

		System.out.println("\nFunction : playWithVaridiacArguments");
		playWithVaridiacArguments();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
 		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

