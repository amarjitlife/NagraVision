/*
javac JavaInterfaces.java -d build
java -cp build/ learnJava.JavaInterfaces
*/

package learnJava;

import java.util.Arrays;
import java.util.Comparator;
import java.util.ArrayList;

//____________________________________________________

// Defines What To Do
interface IntSequence {
    boolean hasNext();
    int next();
}

// Defines How/When/Where/Which Way etc.. To Do
// class DigitSequence { //implements IntSequence {
class DigitSequence implements IntSequence {
    private int number;

    public DigitSequence(int n) { number = n;           }
    public boolean hasNext()    { return number != 0;   }

    public int next() {
        int result = number % 10;
        number /= 10;
        return result;
    }
    
    public int rest() { return number; }
}


// class SquareSequence { //implements IntSequence {
class SquareSequence implements IntSequence {
    private int i;
    public boolean hasNext()    {  return true;          }

    public int next() {
        i++;
        return i * i;  
    }
}

class IntSequenceDemo {
    // public static double average(DigitSequence seq, int n) {
    //     int count = 0;
    //     double sum = 0;
    //     while (seq.hasNext() && count < n) {
    //         count++;
    //         sum += seq.next();
    //     }
    //     return count == 0 ? 0 : sum / count;
    // }

    // public static double average(SquareSequence seq, int n) {
    //     int count = 0;
    //     double sum = 0;
    //     while (seq.hasNext() && count < n) {
    //         count++;
    //         sum += seq.next();
    //     }    //     return count == 0 ? 0 : sum / count;
    // }

    public static double average(IntSequence seq, int n) {
        int count = 0;
        double sum = 0;
        while (seq.hasNext() && count < n) {
            count++;
            sum += seq.next();
        }
        return count == 0 ? 0 : sum / count;
    }

    public static void playWithInterfaces() {
        SquareSequence squares = new SquareSequence();
        double avg = average(squares, 100);
        System.out.println("Average of first 100 squares: " + avg);
        
        IntSequence digits = new DigitSequence(1729);
        while (digits.hasNext()) 
        	System.out.print(digits.next() + " ");
        System.out.println();
        
        digits = new DigitSequence(1729);
        avg = average(digits, 100);
            // Will only look at the first four sequence values
        System.out.println("Average of the digits: " + avg);
    }
}

//____________________________________________________

interface Identified {
    default int getId() { //Function With Default Implemenation
        System.out.println("Identified getId() Called...");
        return Math.abs(hashCode()); 
    } 
}

interface Person {
    String getName();
    default int getId() { //Function With Default Implemenation
        System.out.println("Person getId() Called...");
         return 0; 
    } 
}

class Employee implements Person, Identified {
    protected String name;
    protected double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName()     { return name;      }
    public double getSalary()   { return salary;    }
    public int getId() { 
        System.out.println("Employee getId() Called...");
        // return Identified.super.getId(); 
        // return Person.super.getId(); 
        // return super.getId(); // Compile Time Error
        return Identified.super.getId();         
    }
}

class EmployeeDemo {
    public static void playWithMutipleInterfaces() {
        Employee gabbar = new Employee("Gabbar Singh", 50000.0);
        System.out.println( gabbar.getName() );
        System.out.println( gabbar.getSalary() );
        System.out.println( gabbar.getId() );
    }
}

//____________________________________________________

class EmployeeAgain extends Employee implements Comparable<EmployeeAgain> {        
    public EmployeeAgain(String name, double salary) {
        super(name, salary);
    }
        
    public int compareTo(EmployeeAgain other) {
        return Double.compare(salary, other.salary);
    }
}

//____________________________________________________

// import java.util.Arrays;
// import java.util.Comparator;

class LengthComparator implements Comparator<String> {
    public int compare(String first, String second) {
        return first.length() - second.length();
    }
}

// class FirstLetterComparator implements Comparator<String> {
//     public int compare(String first, String second) {
//         // return first.length() - second.length();
//     }
// }

class LastLetterComparator implements Comparator<String> {
    public int compare(String first, String second) {
        return first.charAt( first.length() - 1) - second.charAt( second.length() - 1);
        // return first.length() - second.length();
    } 
}   

class EvenLengthComparator implements Comparator<String> {
    public int compare(String first, String second) {
        return first.length() % 2 ;
        // return first.length() - second.length();
    }
}

class SortDemo {
    public static void  playWithComparatorInterface() {

        String[] friends = { "Peter", "Paul", "Mary" };
        Arrays.sort(friends); // friends is now ["Mary", "Paul", "Peter"]
        System.out.println(Arrays.toString(friends));
        // [Mary, Paul, Peter]
        
        friends = new String[] { "Zoooong", "Peter", "Pauuul", "Ziiing", "Mary", "Ding", "Dooong" };
        Arrays.sort(friends, new LengthComparator());
        System.out.println(Arrays.toString(friends));        
        // [Mary, Ding, Peter, Pauuul, Ziiing, Dooong, Zoooong]
    
        friends = new String[] { "Zoooong", "Peter", "Pauuul", "Ziiing", "Mary", "Ding", "Dooong" };
        Arrays.sort(friends, new LastLetterComparator());
        System.out.println(Arrays.toString(friends)); 
        // [Zoooong, Ziiing, Ding, Dooong, Pauuul, Peter, Mary]

        friends = new String[] { "Zoooong", "Peter", "Pauuul", "Ziiing", "Mary", "Ding", "Dooong" };
        Arrays.sort(friends, new EvenLengthComparator());
        System.out.println(Arrays.toString(friends)); 
       // [Zoooong, Peter, Pauuul, Ziiing, Mary, Ding, Dooong]


        friends = new String[] { "Zoooong", "Peter", "Pauuul", "Ziiing", "Mary", "Ding", "Dooong" };
        Arrays.sort(friends, (first, second) -> first.length() - second.length() );
        System.out.println(Arrays.toString(friends)); 


        ArrayList<String> friendsNull = new ArrayList<>( Arrays.asList( null, "Peter", "Pauuul", null, "Mary", "Ding", "Dooong"));
        friendsNull.removeIf( element -> element == null );
        System.out.println( friendsNull ); 
    }
}

//____________________________________________________


//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________

public class JavaInterfaces {

	public static void main( String[] args ) {
 		System.out.println("\nFunction : playWithInterfaces");
 		IntSequenceDemo.playWithInterfaces();

		System.out.println("\nFunction : EmployeeDemo.playWithMutipleInterfaces");
        EmployeeDemo.playWithMutipleInterfaces();

		System.out.println("\nFunction : SortDemo.playWithComparatorInterface");
        SortDemo.playWithComparatorInterface();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
 		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}
