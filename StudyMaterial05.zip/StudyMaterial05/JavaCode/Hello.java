/*
javac Hello.java -d ClassFiles
java -cp ClassFiles/ learnJava.Hello 
*/

package learnJava;

// package learnJava.java;

public class Hello {
	public static void main( String[] args ) {
		System.out.println("Hello World!!!");
	}
}

