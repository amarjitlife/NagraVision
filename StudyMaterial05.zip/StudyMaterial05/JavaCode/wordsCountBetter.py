import string
import sys

wordsCount = {}
fileNames = sys.argv[ 1 : ] # List Of File Names

for filename in fileNames:
	for line in open(filename):
		for word in line.split():
			word = word.strip()
			if len( word ) >= 2:
				wordsCount[word] = wordsCount.get(word, 0) + 1

for word in sorted( wordsCount ):
	print("'{0}' Word Count: {1} ".format(word, wordsCount[ word ]))
