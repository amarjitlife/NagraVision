import string
import sys

wordsCount = {}
fileNames = sys.argv[ 1 : ] # List Of File Names

for filename in fileNames:
	openedFile = open(filename)
	lines = openedFile.readlines()

	for line in lines:
		words = line.split()
		for word in words:
			word = word.strip()
			if len( word ) >= 2:
				wordsCount[word] = wordsCount.get(word, 0) + 1

for word in sorted( wordsCount ):
	print("'{0}' Word Count: {1} ".format(word, wordsCount[ word ]))

 