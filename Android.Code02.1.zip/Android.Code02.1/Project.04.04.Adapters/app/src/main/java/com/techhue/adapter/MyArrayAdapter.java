package com.techhue.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;


/**
 * Listing 4-21: Customizing the Array Adapter
 */
public class MyArrayAdapter extends ArrayAdapter<MyClass>
{

    int resource;

    public MyArrayAdapter(Context context,
                          int _resource,
                          List<MyClass> items) {
        super(context, _resource, items);
        resource = _resource;
    }

    //  Implemented At Adapter
    //  Adapter Method getView() will be Called By ListView
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Create and inflate the View to display
        LinearLayout newView;

        if (convertView == null) {
            // Inflate a new view if this is not an update.
            newView = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater layoutInflater;
            layoutInflater = (LayoutInflater) getContext().getSystemService(inflater);
            // It Parses UI XML File
            // Creates UI Nodes Or View Objects
            // Construct View Hierarchy or View Tree
            // Attach This View Hierarchy To Node newView
            // Here resource contains UI XML Passed By Activity
            layoutInflater.inflate(resource, newView, true);
        } else {
            // Otherwise we'll update the existing View
            newView = (LinearLayout) convertView;
        }

        // Getting Data From Model
        MyClass classInstance = getItem(position);

        // Initialising View Object With Data
        TextView text = (TextView) newView.findViewById(android.R.id.text1);
        text.setText(classInstance.name);

        // TODO Retrieve values to display from the
        // classInstance variable.

        // TODO Get references to the Views to populate from the layout.
        // TODO Populate the Views with object property values.

        return newView;
    }
}