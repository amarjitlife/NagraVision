
#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() {
	printf("\nDoing Bhangra.... Balllee Balleeee");
}

void doBharatnatyam() {
	printf("\nDoing doBharatnatyam... Eye and Hand Moments");
}

int main() {
					// Constructor 
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\n ID  : %d", gabbar.id );
	printf("\n Name: %s", gabbar.name );
	gabbar.dance();

	Human tamna = { 100, "Tammna...", doBharatnatyam };
	printf("\n ID  : %d", tamna.id );
	printf("\n Name: %s", tamna.name );
	tamna.dance();

	return 0;
}

