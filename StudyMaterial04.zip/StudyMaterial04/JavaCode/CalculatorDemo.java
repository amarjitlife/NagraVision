/*
javac JavaInterfaces.java -d build
java -cp build/ learnJava.JavaInterfaces
*/

package learnJava;

import java.util.Arrays;
import java.util.Comparator;

//____________________________________________________

// SAM Interfaces
// Single Abstract Method Interfaces
@FunctionalInterface
interface Operator {
	int operate(int x, int y);
} 

class Math {
	public static int add(int a, int b) 	  { return a + b; }
	public static int substract(int a, int b) { return a - b; }
	public static int multiply(int a, int b)  { return a * b; }
	// public  int divide(int a, int b) 	  { if ( b != 0 ) return a / b; }
}

class Calculator {
	// Polymorphic Function
	//		Mechnism : Passing Behaviour To Behaviour
	public static int calculate(int x, int y, Operator operator) {
		return operator.operate( x, y );
	}
}

//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________
//____________________________________________________

public class CalculatorDemo {

	public static void main( String[] args ) {
		int a  = 40, b = 10, result = 0;

		result = Calculator.calculate( a, b, Math::add );
		System.out.println("\nResult :" + result );

		result = Calculator.calculate( a, b, Math::substract );
		System.out.println("\nResult :" + result );

		result = Calculator.calculate( a, b, Math::multiply );
		System.out.println("\nResult :" + result );

											 // Lamba Expression	
		result = Calculator.calculate( a, b, (aa, bb) -> aa + bb );
		System.out.println("\nResult :" + result );

		result = Calculator.calculate( a, b, (aa, bb) -> aa - bb );
		System.out.println("\nResult :" + result );

		result = Calculator.calculate( a, b, (aa, bb) -> aa * bb );
		System.out.println("\nResult :" + result );

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}
