
// package learnKotlin;

fun add( a: Int, b: Int ) = a + b
fun substract( a: Int, b: Int ) : Int {
	return a - b
}

fun calculator( x: Int, y: Int, operate: (Int, Int) -> Int ) : Int {
	return operate(x, y);
}

fun main() {
	var a = 40
	var b = 10
	var result: Int

	result = calculator(a, b, ::add)
	println("Result : $result ")

	result = calculator(a, b, ::substract)
	println("Result : $result ")
}

