___________________________________________________________

DAY 1 
___________________________________________________________

A1. READING ASSINGMENTS [ MUST ]
	Single Precision Floating Point [ Wikipedia Arctile ]
	Double Precision Floating Point [ Wikipedia Arctile ]

A2. READING ASSINGMENTS [ MUST MUST ]
	Chapter 05: Pointers and Array
	Reference: The C Programming Language
				Kernigham and Dennis Rithie

___________________________________________________________

DAY 02
___________________________________________________________

A1. READING ASSINGMENTS [ MUST ]
	Single Precision Floating Point [ Wikipedia Arctile ]
	Double Precision Floating Point [ Wikipedia Arctile ]

A2. READING ASSINGMENTS [ MUST MUST ]
	Chapter 05: Pointers and Array
	Reference: The C Programming Language
				Kernigham and Dennis Rithie

A3. CODING ASSINGMENTS [ MUST MUST ]
	Simulate 2D and 3D Dynamic Arrays in C

A4. CODING PRACTICE AND REVISION JAVA CODE [ MUST MUST ]
	Practice and Revise Java Code Done Till Now

___________________________________________________________

DAY 03
___________________________________________________________

A1. JAVA CODE PRACTICE [ MUST MUST ]
	Practice and Experiment Java Code 
		Done Till Now
		Type Yourself!!!

___________________________________________________________

DAY 04
___________________________________________________________

A1. JAVA CODE PRACTICE [ MUST MUST ]
	Practice and Experiment Java Code 
		Done Till Now
		Type Yourself!!!	

A2. READING ASSINGMENTS
	
	[ BEGINNERS LEVEL ]
		The Complete Reference In Java By Herbet Schildt
	
		PHASE 01 - Complete In Next 2 Days
			Chapters 6, 7, 8, 9, 15, 17, 19
		PHASE 02 - Complete In Saturday and Sunday
			Chapters 1 to 19

	[ INTERMEDIATE+ LEVEL ] - Complete In Next 2 Days
		Core Java for the Impatient, by Cay S. Horstmann  
		First 04 Chapters

___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________

