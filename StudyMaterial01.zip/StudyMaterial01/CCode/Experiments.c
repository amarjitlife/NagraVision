
#include <stdio.h>
#include <limits.h>

//________________________________________________________
//________________________________________________________

// BAD CODE
int sum(int x, int y) {

	// MIN << x, y <= MAX
	int result = x + y;

	// MIN << result <= MAX	
	return result;
}

void playWithSum() {
	int a = 0, b = 0, result = 0;
	printf("\nResult : %d", sum(10, 20) ) ;
	printf("\nResult : %d", sum(99999, 99999) ) ;
	printf("\nResult : %d", sum(999999, 999999) ) ;
	printf("\nResult : %d", sum(9999999, 9999999) ) ;
	printf("\nResult : %d", sum(99999999, 99999999) ) ;
	printf("\nResult : %d", sum(999999999, 999999999) ) ;

	a = 2147483647;
	b = 1;
	result = sum( a, b );
	printf("\nResult : %d", result ) ; // Result : -2147483648

	a = -2147483648;
	b = -1;
	result = sum( a, b );
	printf("\nResult : %d", result ) ; // Result : 2147483647
}

//________________________________________________________

int summation( int a, int b ) {
	int result = 0;

	if( (( b > 0 ) && ( a > ( INT_MAX - b ) ))  ||
		(( b < 0 ) && ( a < ( INT_MIN - b ) )) ) {
		printf("\nCan't Calulate Sum For Given a And b");
	} else {
		result = a + b;
	}

	return result;
}

void playWithSummation() {
	int a = 0, b = 0, result = 0;
	a = 2147483647;
	b = 1;
	result = summation( a, b );
	printf("\nResult : %d", result ) ; // Result : -2147483648

	a = -2147483648;
	b = -1;
	result = summation( a, b );
	printf("\nResult : %d", result ) ; // Result : 2147483647
}

//________________________________________________________

void playWithFloatingPoint() {
	float f = 3.0;
	float f1 = 3.0000001;
	float f2 = 2.9999999;

	if ( f == 3 ) {
		printf("\nEqual");
	} else {
		printf("\nUnEqual")
	}

	if ( f1 == f2 ) {
		printf("\nEqual");
	} else {
		printf("\nUnEqual")
	}
}


//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________
//________________________________________________________

void main() {
	printf("\nFunction : playWithSum");
	playWithSum();

	printf("\nFunction : playWithSummation");
	playWithSummation();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
}