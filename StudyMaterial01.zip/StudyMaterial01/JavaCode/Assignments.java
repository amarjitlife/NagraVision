___________________________________________________________

DAY 1 
___________________________________________________________

A1. READING ASSINGMENTS [ MUST ]
	Single Precision Floating Point [ Wikipedia Arctile ]
	Double Precision Floating Point [ Wikipedia Arctile ]

A2. READING ASSINGMENTS [ MUST MUST ]
	Chapter 05: Pointers and Array
	Reference: The C Programming Language
				Kernigham and Dennis Rithie

___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________
___________________________________________________________

