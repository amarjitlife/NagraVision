/*
javac JavaFoundation.java -d build
java -cp build/ learnJava.JavaFoundation 
*/

package learnJava;

import java.util.Random;

// package learnJava.java;

class ImportDemo {
	public void playWithRandom() {
		// Creating Object/Instance Of Random Class Type
		Random random = new Random();

		//	Invoing random Member Functions/Methods
		System.out.println( random.nextInt() );
		System.out.println( random.nextInt() );
		System.out.println( random.nextInt() );
	}
}

class NumberDemo {
	public static int sum(int x, int y) {
		int result = x + y;
		return result;
	}

	public static int summation( int a, int b ) {
		int result = 0;

		if( (( b > 0 ) && ( a > ( Integer.MAX_VALUE - b ) ))  ||
			(( b < 0 ) && ( a < ( Integer.MIN_VALUE - b ) )) ) {
			System.out.printf("\nCan't Calulate Sum For Given a And b");
		} else {
			result = a + b;
		}

		return result;
	}

	public static void playWithSum() {
		int a = 0, b = 0, result = 0;

		a = 2147483647;
		b = 1;
		result = sum( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : -2147483648

		a = -2147483648;
		b = -1;
		result = sum( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : 2147483647
	}

	public static void playWithSummation() {
		int a = 0, b = 0, result = 0;

		a = 2147483647;
		b = 1;
		result = summation( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : -2147483648

		a = -2147483648;
		b = -1;
		result = summation( a, b );
		System.out.printf("\nResult : %d", result ) ; // Result : 2147483647
	}

	public static void playWithNumbers() {
        // System.out.println(4000000000); // long literal
        System.out.println(4000000000L); // long literal
        System.out.println(0xCAFEBABE); // hex literal
        System.out.println(0b1001); // binary literal
        System.out.println(011); // octal literal
        
        // Underscores in literals   
        System.out.println(1_000_000_000); 
        System.out.println(0b1111_0100_0010_0100_0000);
	
        System.out.println( 900 );
        System.out.println( 900.90 );        // Double Type
        System.out.println( 900.90D );       // Double Type
        System.out.println( 900.90F );        

        // try {
        System.out.println(1.0 / 0.0); 
        System.out.println(-1.0 / 0.0);
        System.out.println(0.0 / 0.0);
        // catch( ) {} // Won't Work...
		// Infinity
		// -Infinity
		// NaN

        // Throws The Exception
        // 		java.lang.ArithmeticException
        // System.out.println( 0 / 0 );
        System.out.println(1.0 / 0.0  == Double.POSITIVE_INFINITY ) ; 
        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY );
        System.out.println(0.0 / 0.0 == Double.NaN );
  		// true
		// true
		// false

        System.out.println( Double.isFinite( 1.0 / 0.0 ) ) ; 
        System.out.println( Double.isFinite( 1.0 / 0.0 ) ) ; 
        System.out.println( Double.isInfinite( -1.0 / 0.0 ) ) ; 
        System.out.println( Double.isInfinite( -1.0 / 0.0 ) ) ; 
        System.out.println( Double.isNaN( 0.0 / 0.0 ) );

       System.out.println(2.0 - 1.1);
       // System.out.println( (2.0 - 1.1) - 0.9 <= EPISOLN );
        
        // Character literals
        System.out.println('J'); 
        System.out.println('J' == 74); 
        System.out.println('\u004A'); 
        System.out.println('\u263A'); 
 
	}
}

public class JavaFoundation {
	public static void playWithImportDemo() {
		ImportDemo importDemo = new ImportDemo();
		importDemo.playWithRandom();
	}

	public static void playWithNumberDemo() {
		NumberDemo.playWithSum();
		NumberDemo.playWithSummation();
		NumberDemo.playWithNumbers();
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction : playWithImportDemo"); 
		playWithImportDemo();

		System.out.println("\nFunction : playWithNumberDemo");
		playWithNumberDemo();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

